<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-progressbar .meter {background: '.$vars['main_site_color'].';}';
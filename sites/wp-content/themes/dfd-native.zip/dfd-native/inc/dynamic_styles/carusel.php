<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-arrows-style_1 .dfd-slider-control:hover > i{'
				. 'color: '.$vars['main_site_color'].';'
			. '}';
$output .= '.dfd-arrows-style_1 .dfd-slider-control:hover:after{'
				. 'background: '.$vars['main_site_color'].';'
			. '}';
$output .= '.dfd-arrows-style_2 .dfd-slider-control:hover i{'
				. 'color: '.$vars['main_color_darken_5'].';'
			. '}';
$output .= '.dfd-arrows-style_3 .dfd-slider-control:after, .dfd-arrows-style_4 .dfd-slider-control:after{'
				. 'background: '.$vars['main_site_color'].';'
			. '}';
$output .= '.dfd-arrows-style_5 .dfd-slider-control{'
				. 'background: '.$vars['main_site_color'].';'
			. '}';

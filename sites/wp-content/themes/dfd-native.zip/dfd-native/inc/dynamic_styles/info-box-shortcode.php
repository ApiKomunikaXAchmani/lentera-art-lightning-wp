<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-info-box .icon-wrapper .info-box-icon-text, .dfd-info-box.style-2 .icon-wrapper .module-icon {background: '.$vars['main_site_color'].';}';

$output .= '.dfd-info-box.style-3 .icon-wrapper .module-icon {color: '.$vars['main_site_color'].';}';
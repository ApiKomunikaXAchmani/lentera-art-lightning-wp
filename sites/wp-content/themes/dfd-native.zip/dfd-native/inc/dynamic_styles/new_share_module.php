<?php

if (!defined('ABSPATH')) {
	exit;
}
$output .= '.dfd-new-share-module .front-share ,.dfd-new-share-module .back-share {'
		   . 'font-family:' . $vars['content_title_big-font-family'] . ';'
		   . '}';
$output .= '.dfd-new-share-module ul li a {'
		   . 'color:' . $vars['content_title_big-color'] . ';'
		   . '}';

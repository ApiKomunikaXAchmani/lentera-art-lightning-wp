<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-announce-module-wrap.style-2 i {background: '.$vars['main_site_color'].';}';
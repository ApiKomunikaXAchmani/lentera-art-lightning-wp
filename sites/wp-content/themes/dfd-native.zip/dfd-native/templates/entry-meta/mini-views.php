<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span><?php echo Dfd_Theme_Helpers::dfd_posts_view_counter(get_the_id()); ?></span>